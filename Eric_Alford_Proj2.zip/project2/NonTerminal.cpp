//
//  NonTerminal.cpp
//  project2
//
//  Created by Eric Alford on 9/27/12.
//  Copyright (c) 2012 Eric Alford. All rights reserved.

#include "NonTerminal.h"

void NonTerminal::incFoIndex(){
    foIndex++;
}

void NonTerminal::incFIndex(){
    fIndex++;
}

int NonTerminal::getFIndex(){
    return fIndex;
}

int NonTerminal::getFoIndex(){
    return foIndex;
}

bool addToFirst(string first[], string token, int index){
    bool flag = true;
    for(int i = 0; i<index; i++){
        if(first[i] == token)
            flag = false;
    }
    
    if(flag)           //if token was not found in the set, add it to the set.
        first[index] = token;
    
    return flag;
}

bool addToFollow(string follow[], string token, int index){
    bool flag = true;
    if(token == "#")
        flag = false;
    else{
        for(int i = 0; i<index; i++){
            if(follow[i] == token)      //empty strings do not go in follow sets.
                flag = false;
        }
    }
    
    if(flag)
        follow[index] = token;
    
    return flag;
}

void NonTerminal::createFirstSet(string grammar[][5000], NonTerminal **ntList){
    bool isNonTerminal = false;
    int ntIndex;
    
    for(int i = 0; i<nonTerminalSize; i++){ //if the non-terminal contains the empty string, it should be listed first.
        if(name == ntList[i]->name && ntList[i]->containsEmpty){
            if(addToFirst(firstSet, "#", fIndex))
                fIndex++;
        }
    }

    for(int i = 0; i<rowSize; i++){ //iterate though the entire grammar set.
        
        if(grammar[i][0] == name){  //find the rule(s) for the specific non-terminal
            int j = 2;
            while(grammar[i][j] != "#"){   //rule found, iterate though the whole line.
                isNonTerminal = false;
                for(int l = 0; l<nonTerminalSize; l++){
                    if(grammar[i][j] == ntList[l]->name){    //if current iteration is a non-terminal, find it in the ntList.
                        ntIndex = l;
                        isNonTerminal = true;
                    }
                }
                if(isNonTerminal){
                    isNonTerminal = false;
                    for(int b = 0; b<ntList[ntIndex]->fIndex; b++){     //add entire first set EXCEPT #
                        if(ntList[ntIndex]->firstSet[b] != "#"){
                            if(addToFirst(firstSet, ntList[ntIndex]->firstSet[b], fIndex))
                                fIndex++;
                        }
                    }
                    
                    if(ntList[ntIndex]->containsEmpty){ //if nt contains the empty string, bring j to the next symbol in rule to analyze.
                        j++;
                        if(grammar[i][j] == "#"){ //end of rule has been reached and all symbols are nt's with #.
                            if(addToFirst(firstSet, "#", fIndex))
                                fIndex++;
                        }
                    }
                    else{
                        while(grammar[i][j] != "#")    //bring j to end of line and proceed with next rule.
                            j++;
                    }
                }
                
                
                else{    //We've reached a terminal. Add it and exit the rule.
                    if(addToFirst(firstSet, grammar[i][j], fIndex))
                        fIndex++;
                    while(grammar[i][j] != "#")    //bring j to end of line and proceed with next rule.
                        j++;
                }
            }
        }
    }
}

int isNonTerminal(string token, NonTerminal **ntList, int nonTerminalSize){ //if it's a nt, return the index in the nt array.
    int isNonTerminal = -1;
    for(int l = 0; l<nonTerminalSize; l++){ //check to see if current symbol is a non-terminal.
        if(token == ntList[l]->name)
            isNonTerminal = l;
    }
    return isNonTerminal;
}

void NonTerminal::createFollowSet(string grammar[][5000], NonTerminal **ntList){
    //Pass 1 will only create the sets following follow set rule number 3.
    for(int i = 0; i<rowSize; i++){ //iterate though the entire grammar set for pass 1.
        if(i == 0 && grammar[i][0] == name){ //if we are referring to the start symbol in the grammar. Add eof to the set.
            if(addToFollow(followSet, "$", foIndex))
               foIndex++;
        }
        
        int j = 1;
        while(grammar[i][j+1] != "#"){   //bring j to the end of the rule
            j++;
        }
            
        //analyze the rule only if it contains symbols and the second from the last symbol is a non-terminal.
        while(grammar[i][j] != "->"){   //analyze the entire rule.
            
            int isLastNonTerminal = isNonTerminal(grammar[i][j], ntList, nonTerminalSize);
            if(isLastNonTerminal != -1){
                int isSlNonTerminal = isNonTerminal(grammar[i][j-1], ntList, nonTerminalSize);
                if(isSlNonTerminal != -1){
                    if(ntList[isSlNonTerminal]->name == name){  //if second to last is an nt that we are referring to.
                        for(int k = 0; k<ntList[isLastNonTerminal]->fIndex; k++){   //add entire first set to follow set.
                            if(addToFollow(followSet, ntList[isLastNonTerminal]->firstSet[k], foIndex)){
                                foIndex++;
                            }
                        }
                    }
                }
                j--;
            }
            else{   //the last symbol is not a nt.
                int isSlNonTerminal = isNonTerminal(grammar[i][j-1], ntList, nonTerminalSize);
                if(isSlNonTerminal != -1){
                    if(ntList[isSlNonTerminal]->name == name){  //if second to last is an nt that we are referring to.
                        if(addToFollow(followSet, grammar[i][j], foIndex))
                            foIndex++;
                    }
                }
                j--;
            }
        }
    }//END OF PASS 1 RULE 3
}