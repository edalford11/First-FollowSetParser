//
//  main.cpp
//  project2
//
//  Created by Eric Alford on 9/22/12.
//  Copyright (c) 2012 Eric Alford. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include "NonTerminal.h"

using namespace std;

bool syntaxError, noRule, notListed, leftTerminal, flag = false;
string fileArray[10000];
string nonTerminals[100];
string terminals[100];
string grammar[5000][5000];
int nonTerminalSize, terminalSize, rowSize, columnSize;
string errors[4] = {"ERROR CODE 0", "ERROR CODE 1", "ERROR CODE 2", "ERROR CODE 3"};

bool addToFollow2(string follow[], string token, int index){
    bool flag = true;
    if(token == "#")
        flag = false;
    else{
        for(int i = 0; i<index; i++){
            if(follow[i] == token)      //empty strings do not go in follow sets.
                flag = false;
        }
    }
    
    if(flag)
        follow[index] = token;
    
    return flag;
}

int isNonTerminal2(string token, NonTerminal **ntList, int nonTerminalSize){ //if it's a nt, return the index in the nt array.
    int isNonTerminal = -1;
    for(int l = 0; l<nonTerminalSize; l++){ //check to see if current symbol is a non-terminal.
        if(token == ntList[l]->name)
            isNonTerminal = l;
    }
    return isNonTerminal;
}

void printErrors(){
    if(syntaxError){
        cout << errors[0];
    }
    else{
        if(noRule){
            cout << errors[1];
            cout << "\n";
        }
        if(notListed){
            cout << errors[2];
            cout << "\n";
        }
        if(leftTerminal){
            cout << errors [3];
        }
    }
}

void checkErrors(){
    string::iterator it;
    int j = 0;
    int k = 0;
    
    //add non-terminals to its own array.
    while(fileArray[j] != "#"){
        for (it = fileArray[j].begin(); it < fileArray[j].end(); it++){ //check for syntax.
            if(it == fileArray[j].begin()){ //first token must be a letter
                if(!isalpha(*it)){
                    syntaxError = true;
                    //cout << "Marker 1\n";
                }
            }
            else if(!isalnum(*it)){  //rest of the tokens can be letters or numbers.
                syntaxError = true;
                //cout << "Marker 2\n";
            }
        }
        nonTerminals[j] = fileArray[j];
        j++;
    }
    nonTerminalSize = j;
    j++;    //bring j to the next section
    
    
    //add terminals to its own array.
    while(fileArray[j] != "#"){
        for (it = fileArray[j].begin(); it < fileArray[j].end(); it++){     //check for syntax.
            if(it == fileArray[j].begin()){ //first token must be a letter
                if(!isalpha(*it)){
                    syntaxError = true;
                    //cout << "Marker 3\n";
                }
            }
            if(!isalnum(*it)){
                syntaxError = true;
                //cout << "Marker 4\n";
            }
        }
        terminals[k] = fileArray[j];
        k++;
        j++;
    }
    terminalSize = k;
    j++;
    
    //add grammar to its own array.
    k=0;
    int l = 0;
    while(fileArray[j] != "##"){
        if(k == 0){     //if k == 0 then we are refering to the left side of the grammar.
            for (it = fileArray[j].begin(); it < fileArray[j].end(); it++){ //check for syntax.
                if(it == fileArray[j].begin()){ //first token must be a letter
                    if(!isalpha(*it)){
                        syntaxError = true;
                    }
                }
                else if(!isalnum(*it)){  //rest of the tokens can be letters or numbers.
                    syntaxError = true;
                }
            }
            
            flag = false;   //reset flag every time a symbol is checked to see if it was listed.
            for(int i = 0; i<nonTerminalSize; i++){    //if a non-terminal appears that wasn't listed.
                if(fileArray[j] == nonTerminals[i]){
                    flag = true;
                }
            }
            for(int i = 0; i<terminalSize; i++){   //if terminal appears on the left hand side.
                if(fileArray[j] == terminals[i]){
                    leftTerminal = true;
                    flag = true;        //set this flag to make sure the notListed rule is satisfied below.
                }
            }
            
            if(!flag)
                notListed = true;
            
            for(int i = 0; i<terminalSize; i++){   //if terminal appears on the left hand side.
                if(fileArray[j] == terminals[i]){
                    leftTerminal = true;
                }
            }
            
            grammar[l][k] = fileArray[j];
            k++;
            j++;
            
            if(fileArray[j] != "->")
                syntaxError = true;
        }
        else if(fileArray[j] == "->" && k!=1){
            syntaxError = true;
            j++;
            //cout << "Marker\n";
        }
        else if(k == 1 && fileArray[j] != "->"){
            syntaxError = true;
            j++;
            //cout << "Marker 5\n";
        }
        else if(fileArray[j] == "->" && k == 1){      //this should indicate the -> string.
            grammar[l][k] = fileArray[j];
            k++;
            j++;
        }
        else if(k>1 && fileArray[j] != "#" && fileArray[j] != "##"){
            for (it = fileArray[j].begin(); it < fileArray[j].end(); it++){ //check for syntax.
                if(it == fileArray[j].begin()){ //first token must be a letter
                    if(!isalpha(*it)){
                        syntaxError = true;
                    }
                }
                else if(!isalnum(*it)){  //rest of the tokens can be letters or numbers.
                    syntaxError = true;
                }
            }
            
            flag = false;   //reset flag every time a symbol is checked to see if it was listed.
            for(int i = 0; i<nonTerminalSize; i++){    //if a non-terminal appears that wasn't listed.
                if(fileArray[j] == nonTerminals[i]){
                    flag = true;
                }
            }
            for(int i = 0; i<terminalSize; i++){   //if terminal appears that wasn't listed.
                if(fileArray[j] == terminals[i]){
                    flag = true;
                }
            }
            if(!flag)
                notListed = true;
            
            grammar[l][k] = fileArray[j];
            k++;
            j++;
        }
        else if(fileArray[j] == "#"){   //if we hit #, proceed to the next row in the 2D array for the next rule.
            grammar[l][k] = fileArray[j];
            j++;
            l++;
            k=0;
        }
        else{
            syntaxError = true;
            j++;
            //cout << "Marker 6\n";
        }
    }
    grammar[l][k] = "#";
    rowSize = l+1;  //the rowSize stored for the grammar array.
    
    
    int ruleBinArray[nonTerminalSize];  //binary array will indicate whether all non-Terminals have rules or not
    for(int i = 0; i<nonTerminalSize; i++)
        ruleBinArray[i] = 0;
    
    for(int x = 0; x<nonTerminalSize; x++){   //iterate though the grammar to see if all non-Terminals have a rule.
        for(int i = 0; i<rowSize; i++){         //ERROR CODE 1
            if(nonTerminals[x] == grammar[i][0]){
                ruleBinArray[x] = 1;
            }
        }
    }
    for(int i = 0; i<nonTerminalSize; i++){
        if(ruleBinArray[i] == 0){
            noRule = true;;
            return;
        }
    }
}

void getFile(){
    char c = getchar();
    string word = "";
    int size = 0;
    
    while(!feof(stdin) && word != "##"){
        word = "";
        while(isspace(c) && !feof(stdin)){
            c = getchar();
        }
        while(!isspace(c) && !feof(stdin)){
            word += c;
            c = getchar();
        }
        fileArray[size] = word;
        size++;
        c = getchar();
    }
    
    if(fileArray[size-1] != "##"){
        syntaxError = true;
        //cout << "Marker 7\n";
    }
}

void followPass2(NonTerminal **ntList){
    int j = 0;
    int followAIndex;
    
    //START PASS 2 for rule 2.
    for(int i = 0; i<rowSize; i++){ //iterate though the entire grammar set for pass 2.
        for(int l = 0; l<nonTerminalSize; l++){ //locate the rule symbol in the ntlist.
            if(ntList[l]->name == grammar[i][0]){
                followAIndex = l;
            }
        }
        
        while(grammar[i][j+1] != "#" && grammar[i][j+1] != "##"){   //bring j to the end of the rule.
            j++;
        }
        
        int isLastNonTerminal = isNonTerminal2(grammar[i][j], ntList, nonTerminalSize);
        if(isLastNonTerminal != -1){
            for(int k = 0; k<ntList[followAIndex]->getFoIndex(); k++){   //add entire follow set to the other follow set.
                if(addToFollow2(ntList[isLastNonTerminal]->followSet, ntList[followAIndex]->followSet[k], ntList[isLastNonTerminal]->getFoIndex()))
                    ntList[isLastNonTerminal]->incFoIndex();
            }
            
            while(ntList[isLastNonTerminal]->containsEmpty){  //if last symbol is an nt AND it contains the empty string in the first set.
                j--;
                isLastNonTerminal = isNonTerminal2(grammar[i][j], ntList, nonTerminalSize);
                
                if(isLastNonTerminal != -1){
                    for(int k = 0; k<ntList[followAIndex]->getFoIndex(); k++){   //add entire first set to follow set.
                        if(addToFollow2(ntList[isLastNonTerminal]->followSet, ntList[followAIndex]->followSet[k], ntList[isLastNonTerminal]->getFoIndex()))
                            ntList[isLastNonTerminal]->incFoIndex();
                    }
                }
                else{
                    break;  //if we reach a symbol that is not an nt then break out of the while loop.
                }
            }
        }
        j=0;    //reset j after entire rule has been analyzed
    }
}

void swap(string& first, string& second)
{
    string temp = first;
    first = second;
    second = temp;
}

int findSmallest(string array[ ], int startIndex, int endIndex)
{
    int smallestIndex = startIndex;
    
    for(int i = startIndex + 1; i <= endIndex; i++)
    {
        if(array[i] < array[smallestIndex])
            smallestIndex = i;
    }
    return smallestIndex;
}

void selectionSort(string array[ ], const int arraySize)
{
    int smallestIndex = 0;
    for(int i = 0; i < arraySize; i++)
    {
        smallestIndex = findSmallest(array, i, arraySize - 1);
        swap(array[i], array[smallestIndex]);
    }
}

int main(){
    getFile();
    
    if(syntaxError){ //check for syntax error because the checkErrors method won't work if certain syntax errors exist.
        printErrors();
        return 0;
    }
    
    checkErrors();        //will put the terminals, non-terminals and grammar in their own array.
    
    if(syntaxError || noRule || notListed || leftTerminal){ //if any errors, print them and terminate.
        printErrors();
        return 0;
    }
    
    //No errors found, lets create our first and follow sets.
    NonTerminal *ntList[nonTerminalSize];
    for(int i = 0; i<nonTerminalSize; i++){
        NonTerminal *nt = new NonTerminal(nonTerminals[i], grammar, rowSize, nonTerminalSize);
        ntList[i] = nt;
    }
    

    for(int g = 0; g<4; g++){
        for(int i = 0; i<nonTerminalSize; i++){
            ntList[i]->createFirstSet(grammar, ntList);
        }
    }
    
    
    for(int g = 0; g<4; g++){
        for(int i = 0; i<nonTerminalSize; i++){
            ntList[i]->createFollowSet(grammar, ntList);
        }
    }
    
    for(int g = 0; g<4; g++){
        followPass2(ntList);
    }
    
    //Sorting time yeah!
    for(int z = 0; z<nonTerminalSize; z++){
        selectionSort(ntList[z]->firstSet, ntList[z]->getFIndex());
        selectionSort(ntList[z]->followSet, ntList[z]->getFoIndex());
    }
    
    for(int i = 0; i<nonTerminalSize; i++){
        cout << "FIRST(" << ntList[i]->name << ") = { ";
        for(int j = 0; j<ntList[i]->getFIndex(); j++){
            if(j == ntList[i]->getFIndex() -1){
                cout << ntList[i]->firstSet[j] << " ";
            }
            else
                cout << ntList[i]->firstSet[j] << ", ";
        }
        cout << "}\n";
    }
    for(int i = 0; i<nonTerminalSize; i++){
        cout << "FOLLOW(" << ntList[i]->name << ") = { ";
        for(int j = 0; j<ntList[i]->getFoIndex(); j++){
            if(j == ntList[i]->getFoIndex() -1){
                cout << ntList[i]->followSet[j];
            }
            else
                cout << ntList[i]->followSet[j] << ", ";
        }
        cout << " }\n";
    }
    
    return 0;
}