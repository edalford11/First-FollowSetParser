//
//  NonTerminal.h
//  project2
//
//  Created by Eric Alford on 9/27/12.
//  Copyright (c) 2012 Eric Alford. All rights reserved.
//

#ifndef __project2__NonTerminal__
#define __project2__NonTerminal__

#include <iostream>
#include <string.h>

using namespace std;

class NonTerminal{
private:
    int fIndex, foIndex;
public:
    string name;
    int rowSize, nonTerminalSize;
    bool containsEmpty;
    string firstSet[100];
    string followSet[100];
    
    NonTerminal(string name, string grammar[][5000], int rowSize, int nonTerminalSize){
        this->name = name;
        this->rowSize = rowSize;
        this->nonTerminalSize = nonTerminalSize;
        containsEmpty = false;
        fIndex = 0;
        foIndex = 0;
        
        for(int i = 0; i<rowSize; i++){
            if(grammar[i][0] == name && (grammar[i][2] == "#" || grammar[i][2] == "##")){
                containsEmpty = true;
            }
        }
    }
    ~NonTerminal(){}
    
    void createFirstSet(string [][5000], NonTerminal **);
    void createFollowSet(string [][5000], NonTerminal **);
    int getFIndex();
    int getFoIndex();
    void incFIndex();
    void incFoIndex();
    
};

#endif /* defined(__project2__NonTerminal__) */
